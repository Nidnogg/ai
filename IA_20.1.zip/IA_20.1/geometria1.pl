p(X,Y).
retangulo(p(X1,Y1),p(X2,Y2),p(X3,Y3),p(X4,Y4)).
quadrado(p(X1,Y1),p(X2,Y2),p(X3,Y3),p(X4,Y4)).
circulo(p(X,Y),R).
